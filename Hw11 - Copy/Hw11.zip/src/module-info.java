module module.java {
	requires javafx.graphics;
	exports application;
}