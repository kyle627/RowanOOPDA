module Lab13 {
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
	exports application;
}