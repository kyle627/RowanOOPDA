
public class Tester {

	public static void main(String[] args) {
			Simulator sim = new Simulator();
			//sim.runLongSimulation();
			sim.simulate(500);

	}

}
