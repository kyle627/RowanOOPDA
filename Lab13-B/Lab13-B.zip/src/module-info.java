module Lab13 {
	requires javafx.graphics;
	requires javafx.controls;
	exports application;
}