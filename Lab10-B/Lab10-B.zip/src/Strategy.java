
public interface Strategy {
	RPS choose(RPS last);
}
