
public enum RPS {
	ROCK, PAPER, SCISSORS
}
