module Lab14A {
	requires javafx.graphics;
	requires javafx.controls;
	exports application;
}