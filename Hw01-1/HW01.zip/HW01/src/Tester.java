/**
 * @author Kyle Evangelisto
 * 9/2/2020
 * HW 01
 * Time: 10:00 Am
 */
public class Tester {

	/*
	 * In the MAIN() method, declare integer variables num1 and num2, and sum.  
	 * Also, declare a double variable average. 
	 */
	
	public static void main(String[] args) {
		int num1 = 14;
		int num2 = 21;
		int sum = num1 + num2; //Calculate the sum
		double average = (sum / 2.0); //Calculate the average [as sum divided by 2.0 ].
		//Output to console all the variable values with captions
		System.out.println("The sum of " + num1 + " and " + num2 + " is: " + average + "."); 
	
	}
	


}
