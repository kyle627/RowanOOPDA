module FA20_15_Lab15_Chat_Start {
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
	exports application;
	
}