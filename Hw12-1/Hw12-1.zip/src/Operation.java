/**
 * 
 * @author Kyle Evangelisto
 *
 * Addition
 *
 */
public interface Operation {
	int operation(int a, int b);
}
