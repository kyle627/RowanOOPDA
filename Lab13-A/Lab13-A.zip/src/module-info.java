module module.java {
	requires javafx.graphics;
	requires javafx.controls;
	exports application;
}