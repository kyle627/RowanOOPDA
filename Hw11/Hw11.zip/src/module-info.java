module Hw11 {
	requires javafx.graphics;
	exports application;
}