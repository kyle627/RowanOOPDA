module Hw13 {
	requires javafx.graphics;
	requires javafx.controls;
    exports application;
}